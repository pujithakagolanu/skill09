<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Inversion of control</title>
</head>
<body>
   <h2>${msg}</h2>
</body>
</html>